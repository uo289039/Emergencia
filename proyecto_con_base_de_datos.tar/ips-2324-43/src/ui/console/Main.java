package ui.console;

public class Main {

	public static void main(String[] args) {
		new Console().run();
	}

}
