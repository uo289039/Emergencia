package model;

public enum Tipo {
	
	MONTANA,
	RUTA

}
